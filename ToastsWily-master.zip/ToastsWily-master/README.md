# ToastsWily
Displaying messages using toast
